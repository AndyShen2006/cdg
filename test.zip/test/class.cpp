#include "class.h"

template <bool aaa>
void MyClass<aaa>::changeA(int n)
{
    a = n;
}