template <bool aaa = false>
class MyClass {
public:
    int a = aaa;
    void changeA(int n);
};