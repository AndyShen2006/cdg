#include "class.h"
#include <bits/stdc++.h>

using namespace std;

int main()
{
    MyClass<true> a;
    a.changeA(2);
    cout << a.a;
    return 0;
}